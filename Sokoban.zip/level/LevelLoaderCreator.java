package level;

public interface LevelLoaderCreator {
	public GeneralLevelLoader create();
}
