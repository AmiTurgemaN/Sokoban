package level;

import java.io.OutputStream;

public interface LevelSaver {
	public void saveLevel(OutputStream outputStream);
}
