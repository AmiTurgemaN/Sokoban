package level;

public abstract class GeneralLevelLoaderCreator implements LevelLoaderCreator {

	@Override
	public abstract GeneralLevelLoader create();

}
