package level;

public interface LevelSaverCreator {
	public GeneralLevelSaver create(Level level);
}
