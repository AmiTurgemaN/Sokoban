package commands;

import level.Level;

public interface GeneralCommandCreator {
	public GeneralCommand create(Level level);
}
