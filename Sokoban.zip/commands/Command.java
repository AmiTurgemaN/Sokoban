package commands;

public interface Command {
	public void doCommand(String arg);
	public void execute();
}
