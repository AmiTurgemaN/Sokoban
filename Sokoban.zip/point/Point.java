package point;

public interface Point {
	
	public String toString();
}
