package reciever;

public abstract class GeneralReciever implements Reciever {

	@Override
	public abstract void action();

}
