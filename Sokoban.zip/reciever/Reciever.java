package reciever;

public interface Reciever {

	public void action();
}
