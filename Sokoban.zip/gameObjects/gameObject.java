package gameObjects;

public interface gameObject {
	public objectType getType();
	public char getSymbol();
}
