package gameObjects;

public enum objectType {
	AREA,BOX,PLAYER,WALL,SPACE,BOXEDAREA,AREAPLAYER
}
